﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HavaDurumuUygulaması
{
    internal class WeatherData
    {
        public string Temperature { get; set; }
        public string Description { get; set; }
        public string Day1 { get; set; }
        public string Day2 { get; set; }
        public string Day3 { get; set; }

    }
}

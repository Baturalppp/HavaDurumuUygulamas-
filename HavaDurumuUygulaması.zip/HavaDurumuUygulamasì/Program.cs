﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using HavaDurumuUygulaması;
using Newtonsoft.Json;

namespace HavaDurumuUygulaması
{
    class Program
    {
        private static readonly HttpClient client = new HttpClient();

        static async Task Main(string[] args)
        {
            // API linklerini ve şehir adlarını bir dizi içinde saklayalım
            string[] cities = { "İstanbul", "İzmir", "Ankara" };
            string[] apiLinks = {

                "https://goweather.herokuapp.com/weather/istanbul",
                "https://goweather.herokuapp.com/weather/izmir",
                "https://goweather.herokuapp.com/weather/ankara"
            };

            // Her bir şehir için hava durumu verilerini alalım ve ekrana yazdıralım
            for (int i = 0; i < cities.Length; i++)
            {
                var cityResponse = await GetWeatherData(apiLinks[i]);

                Console.WriteLine($"{cities[i]} Hava Durumu");
                Console.WriteLine("Bugün: " + cityResponse.Temperature + " " + cityResponse.Description);
                Console.WriteLine("Sonraki Günler:");
                Console.WriteLine("1. Gün: " + cityResponse.Day1);
                Console.WriteLine("2. Gün: " + cityResponse.Day2);
                Console.WriteLine("3. Gün: " + cityResponse.Day3);
                Console.WriteLine("---------------------------------------------");
            }
        }

        public static async Task<WeatherData> GetWeatherData(string uri)
        {
            var responseString = await client.GetStringAsync(uri);
            var weatherData = JsonConvert.DeserializeObject<WeatherData>(responseString);
            return weatherData;
        }
    }
}
